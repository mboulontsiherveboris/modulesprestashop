Salut tout le monde !

<p>Mentions légales</p>
<p>Nom de l’entreprise : HOME QUARE ________</p>
<p>Adresse : Sousse ______</p>

<p>Téléphone : +21656388003_____</p>

<p>Gérant(e) : herve _____</p>

<p>E-mail : mherveboris@gmail.com_____</p>

<p>Conformément aux dispositions des articles 6-III et 19 de la Loi n° 2004-575 du 21 juin 2004 pour la Confiance dans l’économie numérique, dite L.C.E.N., nous portons à la connaissance des utilisateurs et visiteurs du site : xxxxx.yyy les informations suivantes :
    </p>

    <p>1. Informations légales :</p>

    <p>Statut du propriétaire : Auto entrepreneur / S.A.R.L / SAS etc..</p>
    <p>Le Propriétaire est : __herve __</p>
    <p>Adresse postale du propriétaire : 3003 sfax  </p>
 
    <p>Le Créateur du site est : www.dot-it.tn</p>
Le Responsable de la  publication est : hb 
Contacter le responsable de la publication : hb
Le responsable de la publication est une personne physique (ou morale)

Le Webmaster est  : votre nom/entreprise
Contacter le Webmaster : votre email….
L’hébergeur du site est : .... (ou un autre)
</p>

2. Présentation et principe :


3. Accessibilité :

4. Acceptation des termes et conditions :

5. Modification des conditions :


6. Limitation de responsabilité :

7. Propriété intellectuelle :

8. Liens hypertextes et cookies :

9. Protection des biens et des personnes – gestion des données personnelles :
<?php
class ns_monmoduledisplayModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $this->setTemplate('module:ns_monmodule/views/templates/front/display.tpl');
    }
}
