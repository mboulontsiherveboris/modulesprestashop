<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_6a84e4f389e52ec81997dc8d85ea3423'] = 'Do darmowej dostawy brakuje';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_f1709919ea3c0f85d587b7f40048b9e7'] = 'Wyświetla komunikat z informacją ile jeszcze trzeba wydać do darmowej dostawy';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_c888438d14855d7d96a2724ee9c306bd'] = 'Zapisano ustawienia';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_c9722f74f95451816de0f8ca3259ae44'] = 'Darmowa dostawa od';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_df0f8742209189457e60ef4d3e225dc8'] = 'Wpisz 0 aby użyć globalnego ustawienia, aktualnie:';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_23c320f434d4420bdbb433faeb1a6812'] = 'Wydaj jeszcze';
$_MODULE['<{gmgetfreeshipping}prestashop>gmgetfreeshipping_dac22669af4470a5768d996a177f9f59'] = 'aby uzyskać darmową dostawę!';
